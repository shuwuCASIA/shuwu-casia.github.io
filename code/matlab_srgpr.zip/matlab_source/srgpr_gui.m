function varargout = srgpr_gui(varargin)
% SRGPR_GUI M-file for srgpr_gui.fig
%      SRGPR_GUI, by itself, creates a new SRGPR_GUI or raises the existing
%      singleton*.
%
%      H = SRGPR_GUI returns the handle to a new SRGPR_GUI or the handle to
%      the existing singleton*.
%
%      SRGPR_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SRGPR_GUI.M with the given input arguments.
%
%      SRGPR_GUI('Property','Value',...) creates a new SRGPR_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before srgpr_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to srgpr_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help srgpr_gui

% Last Modified by GUIDE v2.5 06-Jul-2011 16:14:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @srgpr_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @srgpr_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before srgpr_gui is made visible.
function srgpr_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to srgpr_gui (see VARARGIN)

% Choose default command line output for srgpr_gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% startup
% me = mfilename;                                            % what is my filename
% mydir = which(me); mydir = mydir(1:end-2-numel(me));        % where am I located
% 
% addpath(mydir(1:end-1))
% addpath([mydir,'cov'])
% addpath([mydir,'doc'])
% addpath([mydir,'inf'])
% addpath([mydir,'lik'])
% addpath([mydir,'mean'])
% addpath([mydir,'util'])
% 
% clear me mydir


% UIWAIT makes srgpr_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = srgpr_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from
%        popupmenu1
set(handles.text1,'String','');
str = getCurrentPopupString(handles.popupmenu1);
path = strcat('testImage/',str);
I = imread(path);
handles = guidata(gcbo); % read
handles.lrImg = I;
handles.tempImg = I;
handles.bicu = I;
handles.enlarge = 1;

% show on axes1
% function display(imgAxes,img, sliderh, sliderw, MAXH, MAXW)
imgAxes = handles.axes1;
img = I;
sliderh = handles.slider11;
sliderw = handles.slider12;
MAXH = 256; MAXW = 256;
    [x y z] = size(img);
    if x > MAXH
        h = MAXH;
        set(sliderh,'Visible','on');
        set(sliderh,'Enable','on');
        set(sliderh,'Min',0,'Max',x-MAXH,'SliderStep',[0.01 0.1]);
        set(sliderh,'value',0);
    else h = x;
        set(sliderh,'Visible','off');
        set(sliderh,'Enable','off');
    end
    if y > MAXW
        w = MAXW;
        set(sliderw,'Visible','on');
        set(sliderw,'Enable','on');
        set(sliderw,'Min',0,'Max',x-MAXW,'SliderStep',[0.01 0.1]);
        set(sliderw,'value',0);
    else w = y;
        set(sliderw,'Visible','off');
        set(sliderw,'Enable','off');
    end

    axes(imgAxes);
    a = get(gca,'position');
    set(imgAxes,'position',[a(1) a(2)+a(4)-h w h])
    img_pos = get(gca,'position');
    a = get(sliderh,'position');
    set(sliderh,'position',[img_pos(1)+img_pos(3) img_pos(2) a(3) img_pos(4)]);
    set(sliderw,'position',[img_pos(1) img_pos(2)-a(3) img_pos(3) a(3)]);

    dh = get(sliderh,'value');
    dw = get(sliderw,'value');

    imshow(img(dh+1:h+dh,dw+1:w+dw,:))
    
% show on axes2
% function display(imgAxes,img, sliderh, sliderw, MAXH, MAXW)
imgAxes = handles.axes2;
img = I;
sliderh = handles.slider21;
sliderw = handles.slider22;
MAXH = 256*2; MAXW = 256*2;
    [x y z] = size(img);
    if x > MAXH
        h = MAXH;
        set(sliderh,'Visible','on');
        set(sliderh,'Enable','on');
        set(sliderh,'Min',0,'Max',x-MAXH,'SliderStep',[0.01 0.1]);
        set(sliderh,'value',0);
    else h = x;
        set(sliderh,'Visible','off');
        set(sliderh,'Enable','off');
    end
    if y > MAXW
        w = MAXW;
        set(sliderw,'Visible','on');
        set(sliderw,'Enable','on');
        set(sliderw,'Min',0,'Max',x-MAXW,'SliderStep',[0.01 0.1]);
        set(sliderw,'value',0);
    else w = y;
        set(sliderw,'Visible','off');
        set(sliderw,'Enable','off');
    end

    axes(imgAxes);
    a = get(gca,'position');
    set(imgAxes,'position',[a(1) a(2)+a(4)-h w h])
    img_pos = get(gca,'position');
    a = get(sliderh,'position');
    set(sliderh,'position',[img_pos(1)+img_pos(3) img_pos(2) a(3) img_pos(4)]);
    set(sliderw,'position',[img_pos(1) img_pos(2)-a(3) img_pos(3) a(3)]);
    
    dh = get(sliderh,'value');
    dw = get(sliderw,'value');

    imshow(img(dh+1:h+dh,dw+1:w+dw,:))
    
% show on axes3
% function display(imgAxes,img, sliderh, sliderw, MAXH, MAXW)
imgAxes = handles.axes3;
img = I;
sliderh = handles.slider31;
sliderw = handles.slider32;
MAXH = 256*2; MAXW = 256*2;
    [x y z] = size(img);
    if x > MAXH
        h = MAXH;
        set(sliderh,'Visible','on');
        set(sliderh,'Enable','on');
        set(sliderh,'Min',0,'Max',x-MAXH,'SliderStep',[0.01 0.1]);
        set(sliderh,'value',0);
    else h = x;
        set(sliderh,'Visible','off');
        set(sliderh,'Enable','off');
    end
    if y > MAXW
        w = MAXW;
        set(sliderw,'Visible','on');
        set(sliderw,'Enable','on');
        set(sliderw,'Min',0,'Max',x-MAXW,'SliderStep',[0.01 0.1]);
        set(sliderw,'value',0);
    else w = y;
        set(sliderw,'Visible','off');
        set(sliderw,'Enable','off');
    end

    axes(imgAxes);
    a = get(gca,'position');
    set(imgAxes,'position',[a(1) a(2)+a(4)-h w h])
    img_pos = get(gca,'position');
    a = get(sliderh,'position');
    set(sliderh,'position',[img_pos(1)+img_pos(3) img_pos(2) a(3) img_pos(4)]);
    set(sliderw,'position',[img_pos(1) img_pos(2)-a(3) img_pos(3) a(3)]);
    
    dh = get(sliderh,'value');
    dw = get(sliderw,'value');

    imshow(img(dh+1:h+dh,dw+1:w+dw,:))

guidata(gcbo,handles); % write
   

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function str = getCurrentPopupString(hh)
%# getCurrentPopupString returns the currently selected string in the popupmenu with handle hh

%# could test input here
if ~ishandle(hh) 
error('getCurrentPopupString needs a handle to a popupmenu as input')
end

%# get the string - do it the readable way
list = get(hh,'String');
val = get(hh,'Value');
str = list{val};


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = guidata(gcbo); % read
sl = round(str2double(get(handles.edit2,'string')));
if sl<15 || sl>25 || isnan(sl)
    msgbox('Patch size should be between 15 and 25.','Patch Size Error');
    return;
end
    

handles.enlarge = handles.enlarge*2;
I = handles.tempImg;
handles.bicu = imresize(handles.lrImg,handles.enlarge,'bicubic');
tic;
image = rgb2ntsc(I);
h0 = image(:,:,1);
h1 = srgpr2(h0,sl);
[m n] = size(h1);
I = zeros(m,n,3);
I(:,:,1) = h1;
I(:,:,2) = imresize(image(:,:,2),2,'bicubic');
I(:,:,3) = imresize(image(:,:,3),2,'bicubic');
I = ntsc2rgb(I);
sec = toc;
handles.tempImg = I;

% show on axes2
% function display(imgAxes,img, sliderh, sliderw, MAXH, MAXW)
imgAxes = handles.axes2;
img = I;
sliderh = handles.slider21;
sliderw = handles.slider22;
MAXH = 256*2; MAXW = 256*2;
    [x y z] = size(img);
    if x > MAXH
        h = MAXH;
        set(sliderh,'Visible','on');
        set(sliderh,'Enable','on');
        set(sliderh,'Min',0,'Max',x-MAXH,'SliderStep',[0.01 0.1]);
        set(sliderh,'value',0);
    else h = x;
        set(sliderh,'Visible','off');
        set(sliderh,'Enable','off');
    end
    if y > MAXW
        w = MAXW;
        set(sliderw,'Visible','on');
        set(sliderw,'Enable','on');
        set(sliderw,'Min',0,'Max',x-MAXW,'SliderStep',[0.01 0.1]);
        set(sliderw,'value',0);
    else w = y;
        set(sliderw,'Visible','off');
        set(sliderw,'Enable','off');
    end

    axes(imgAxes);
    a = get(gca,'position');
    set(imgAxes,'position',[a(1) a(2)+a(4)-h w h])
    img_pos = get(gca,'position');
    a = get(sliderh,'position');
    set(sliderh,'position',[img_pos(1)+img_pos(3) img_pos(2) a(3) img_pos(4)]);
    set(sliderw,'position',[img_pos(1) img_pos(2)-a(3) img_pos(3) a(3)]);
    
    dh = get(sliderh,'value');
    dw = get(sliderw,'value');

    imshow(img(dh+1:h+dh,dw+1:w+dw,:))
    
% show on axes3
% function display(imgAxes,img, sliderh, sliderw, MAXH, MAXW)
imgAxes = handles.axes3;
img = handles.bicu;
sliderh = handles.slider31;
sliderw = handles.slider32;
MAXH = 256*2; MAXW = 256*2;
    [x y z] = size(img);
    if x > MAXH
        h = MAXH;
        set(sliderh,'Visible','on');
        set(sliderh,'Enable','on');
        set(sliderh,'Min',0,'Max',x-MAXH,'SliderStep',[0.01 0.1]);
        set(sliderh,'value',0);
    else h = x;
        set(sliderh,'Visible','off');
        set(sliderh,'Enable','off');
    end
    if y > MAXW
        w = MAXW;
        set(sliderw,'Visible','on');
        set(sliderw,'Enable','on');
        set(sliderw,'Min',0,'Max',x-MAXW,'SliderStep',[0.01 0.1]);
        set(sliderw,'value',0);
    else w = y;
        set(sliderw,'Visible','off');
        set(sliderw,'Enable','off');
    end

    axes(imgAxes);
    a = get(gca,'position');
    set(imgAxes,'position',[a(1) a(2)+a(4)-h w h])
    img_pos = get(gca,'position');
    a = get(sliderh,'position');
    set(sliderh,'position',[img_pos(1)+img_pos(3) img_pos(2) a(3) img_pos(4)]);
    set(sliderw,'position',[img_pos(1) img_pos(2)-a(3) img_pos(3) a(3)]);
    
    dh = get(sliderh,'value');
    dw = get(sliderw,'value');

    imshow(img(dh+1:h+dh,dw+1:w+dw,:))


guidata(gcbo,handles); % write
str = int2str(sec);
str = strcat(str,' s');
set(handles.text1,'String',str);



% --- Executes during object creation, after setting all properties.
function slider11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider12_Callback(hObject, eventdata, handles)
% hObject    handle to slider12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
dh = get(handles.slider11,'value');
dw = get(handles.slider12,'value');
handles = guidata(gcbo);
img = handles.lrImg;
a = get(handles.axes1,'position');
w = a(3); h = a(4);
axes(handles.axes1);
imshow(img(dh+1:h+dh,dw+1:w+dw,:))


% --- Executes during object creation, after setting all properties.
function slider12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider21_Callback(hObject, eventdata, handles)
% hObject    handle to slider21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
dh = get(handles.slider21,'value');
dw = get(handles.slider22,'value');
handles = guidata(gcbo);
img = handles.tempImg;
a = get(handles.axes2,'position');
w = a(3); h = a(4);
axes(handles.axes2);
imshow(img(dh+1:h+dh,dw+1:w+dw,:))


% --- Executes during object creation, after setting all properties.
function slider21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider22_Callback(hObject, eventdata, handles)
% hObject    handle to slider22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
dh = get(handles.slider21,'value');
dw = get(handles.slider22,'value');
handles = guidata(gcbo);
img = handles.tempImg;
a = get(handles.axes2,'position');
w = a(3); h = a(4);
axes(handles.axes2);
imshow(img(dh+1:h+dh,dw+1:w+dw,:))


% --- Executes during object creation, after setting all properties.
function slider22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider11_Callback(hObject, eventdata, handles)
% hObject    handle to slider11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
dh = get(handles.slider11,'value');
dw = get(handles.slider12,'value');
handles = guidata(gcbo);
img = handles.lrImg;
a = get(handles.axes1,'position');
w = a(3); h = a(4);
axes(handles.axes1);
imshow(img(dh+1:h+dh,dw+1:w+dw,:))



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider31_Callback(hObject, eventdata, handles)
% hObject    handle to slider31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
dh = get(handles.slider31,'value');
dw = get(handles.slider32,'value');
handles = guidata(gcbo);
img = handles.bicu;
a = get(handles.axes3,'position');
w = a(3); h = a(4);
axes(handles.axes3);
imshow(img(dh+1:h+dh,dw+1:w+dw,:))


% --- Executes during object creation, after setting all properties.
function slider31_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider32_Callback(hObject, eventdata, handles)
% hObject    handle to slider32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
dh = get(handles.slider31,'value');
dw = get(handles.slider32,'value');
handles = guidata(gcbo);
img = handles.bicu;
a = get(handles.axes3,'position');
w = a(3); h = a(4);
axes(handles.axes3);
imshow(img(dh+1:h+dh,dw+1:w+dw,:))


% --- Executes during object creation, after setting all properties.
function slider32_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
