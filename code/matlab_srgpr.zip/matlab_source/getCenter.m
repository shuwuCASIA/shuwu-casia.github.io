function [center] = getCenter(I, s, h, w)
%function [patches patches_mat pm_zero] = getPatch(I, s, d)
% I: image
% l: size of the patch (squre)
% t: distance between patches

[M N] = size(I);
idx = 1;
row = round(linspace(1,M-s+1,h));
col = round(linspace(1,N-s+1,w));
nPatch = h*w;
center = zeros(nPatch,2);
%patches = zeros(s*s, nPatch);
% patches_mat = zeros(s,s,nPatch);
%pm_zero = zeros(s,s, nPatch);

row = round(row+s/2);
col = round(col+s/2);

row_temp = repmat(row,w,1);
col_temp = repmat(col',1,h);

center = [row_temp(:) col_temp(:)];

