function ret = srgpr(imgpath, sl)
warning off
I = imread(imgpath);
bicu = imresize(I,2,'bicubic');
image = rgb2ntsc(I);
h0 = image(:,:,1);
h1 = srgpr2(h0,sl);
[m n] = size(h1);
I = zeros(m,n,3);
I(:,:,1) = h1;
I(:,:,2) = imresize(image(:,:,2),2,'bicubic');
I(:,:,3) = imresize(image(:,:,3),2,'bicubic');
I = ntsc2rgb(I);
imwrite(I,'result.jpg','quality',100);
imwrite(bicu,'bicubic.jpg','quality',100);
ret = 0;