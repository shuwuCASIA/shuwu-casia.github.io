function h2 = srgpr2(h0,sl)

x = h0;

scale = 2;
% sl = 25;  % low res
sh = 2*sl;  % high res

% upsample the LR image
x3 = imresize(x,scale,'bicubic');

[hh ww] = size(x3);

% r of the patch is NOT overlapped
r = 3/4;
h = ceil((hh-sh*(1-r))/(sh*r));
w = ceil((ww-sh*(1-r))/(sh*r));

% GPR functions
hyp.mean = [];
meanfunc = @meanAvg;
covfunc = @covSEiso;
likfunc = @likGauss;

% patch processing
center_hr = getCenter(x3,sh,h,w); % highres center
s = sh;
r = round(center_hr(:,1)-s/2);
c = round(center_hr(:,2)-s/2);
r_hr = [max(1,r) min(hh,r+s-1)];
c_hr = [max(1,c) min(ww,c+s-1)];

center_lr = round(center_hr/scale); % lowres center
s = sl;
r = round(center_lr(:,1)-s/2);
c = round(center_lr(:,2)-s/2);
r_lr = [max(1,r) min(size(x,1),r+s-1)];
c_lr = [max(1,c) min(size(x,2),c+s-1)];

nPatch = size(center_hr,1);
Patch_mat = cell(nPatch,3);

for i = 1:nPatch
    
    % get patch from upsampled LR image (testing patch)
    temp = x3(r_hr(i,1):r_hr(i,2), c_hr(i,1):c_hr(i,2));
    Patch_mat{i,1} = r_hr(i,1):r_hr(i,2);
    Patch_mat{i,2} = c_hr(i,1):c_hr(i,2);
    
    % get patch from LR image (training patch)
    p = x(r_lr(i,1):r_lr(i,2), c_lr(i,1):c_lr(i,2));
    
    % training set
    [X y] = getSet(p,p);
    
    % testing set
    [Xs ys] = getSet(temp,temp);
    
    % contour sampling
    BW = edge(p,'canny',0.1,1);
    BW1 = BW(2:end-1,2:end-1);
    [L,num] = bwlabel(BW1);
    idx1 = [];
    for ii = 1:num
        spl = find(L==ii);
        idx1 = [idx1; spl(1:2:end)];
    end
    idx2 = find(BW1==0);
    boo = randperm(length(idx2));
    idx2 = idx2(boo(1:round(length(idx2)/9)));
    idx = [idx1; idx2];
    
    % initialize GPr parameter
    hyp.cov = [-1.5; log(std(p(:)))];
    hyp.lik = -3;
    
    % MAP estimation
    try
        [hyp] = minimize_lbfgsb(hyp, @gp, 100, @infExact, meanfunc,covfunc, likfunc, X(idx,:), y(idx));
    catch
        Patch_mat{i,3} = temp;
        fprintf('%d fail',i);
        continue;
    end
    if isnan(hyp.cov(1)) || isnan(hyp.cov(2))
        Patch_mat{i,3} = temp;
        fprintf('%d nan\n',i);
        continue;
    end
    
    [M N] = size(temp);
    
    % GPR inference
    [fail ymu] = gp(hyp, @infExact, meanfunc, covfunc, likfunc, X(idx,:), y(idx), Xs);
    
    if fail==0 && length(ymu)~=1 && ~isinf(hyp.cov(1)) && ~isinf(hyp.cov(1)) && ~isinf(hyp.lik)
        temp(2:end-1,2:end-1) = reshape(ymu,M-2,N-2);
    else
        fprintf('fail %d\n',i);
    end
    Patch_mat{i,3} = temp;
end

% fprintf('\n');

h1 = zeros(size(x3));
h1 = constructPatch3(h1,Patch_mat,h,w);

% stage 2

x3 = h1;

% downsample result of stage 1
x2 = imresize(h1,size(x),'bicubic');

% sample index
% ii = 1.02.^[1:130];
% ii = round(cumsum(ii));

for i = 1:nPatch
    
    % get patch from upsampled LR image (testing patch)
    temp = x3(r_hr(i,1):r_hr(i,2), c_hr(i,1):c_hr(i,2));
    
    % get patch from LR image (training patch)
    p = x(r_lr(i,1):r_lr(i,2), c_lr(i,1):c_lr(i,2));
    p2 = x2(r_lr(i,1):r_lr(i,2), c_lr(i,1):c_lr(i,2));
    
    % the center pixel is also included, but may be omitted
    [X9 y9] = getSet(p2,p2);
    [X y] = getSet(p2,p);  % training set
    X = [X y9];
    
    [Xs ys] = getSet(temp,temp); % testing set
    Xs = [Xs ys];
    
    a = p(2:end-1,2:end-1);
    b = p2(2:end-1,2:end-1);
     [foo id] = sort(abs(a(:)-b(:)), 'descend');
    if foo(1) < 0.02
        Patch_mat{i,3} = temp;
        continue;
    else
%         idx = ii(find(ii<=length(id)));
        idx1 = id(1:60);
        idx2 = id(61:10:end);
        idx = [idx1; idx2];
    end
    
    % initialize GPr parameter
    hyp.cov = [-1.5; log(std(p(:)))];
    hyp.lik = -3;
    
    try
        [hyp] = minimize_lbfgsb(hyp, @gp, 100, @infExact, meanfunc,covfunc, likfunc, X(idx,:), y(idx));
    catch
        Patch_mat{i,3} = temp;
        fprintf('%d fail',i);
        continue;
    end
    if isnan(hyp.cov(1)) || isnan(hyp.cov(2))
        Patch_mat{i,3} = temp;
        fprintf('%d nan',i);
        continue;
    end
    
    [M N] = size(temp);
    [fail ymu] = gp(hyp, @infExact, meanfunc, covfunc, likfunc, X(idx,:), y(idx), Xs);
    
    if fail==0 && length(ymu)~=1 && ~isinf(hyp.cov(1)) && ~isinf(hyp.cov(1)) && ~isinf(hyp.lik)
        temp(2:end-1,2:end-1) = reshape(ymu,M-2,N-2);
    end
    Patch_mat{i,3} = temp;
end

% fprintf('\n');

h2 = zeros(size(x3));
h2 = constructPatch3(h2,Patch_mat,h,w);










