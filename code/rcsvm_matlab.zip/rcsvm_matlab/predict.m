function l_hat = predict(data,model);

ker = K(model.sv,data,model.sigma);
f = (sum(diag(model.beta)*ker) + model.beta0)';
l_hat = sign(f);
l_hat(l_hat==0)=1;