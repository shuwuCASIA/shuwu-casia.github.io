function model = train_2(label,data,C,sigma)

% svm classification with constraints on rare class slack variables
% rare examples are denoted as positive instances
% C: penalty parameter
% sigma: kernel parameter

n = size(data,1);
d = size(data,2);
idxn = find(label == -1);
idxp = find(label == 1);
data = [data(idxn,:); data(idxp,:)];
label = [label(idxn); label(idxp)];
np = length(idxp);
nn = length(idxn);
N = n + np;

ker = K(data,data,sigma);
H = zeros(N,N);
H(1:n,1:n) = (label*label').*ker + 1e-10*eye(n,n);
f = [-ones(n,1); 1*ones(np,1)];
lb = zeros(N,1);
ub = [C*ones(nn,1); inf(2*np,1)];
A = [zeros(np,nn) eye(np,np) -1*eye(np,np)];
b = C*ones(np,1);
Aeq = [label; zeros(np,1)]'; beq = 0;
x0 = zeros(N,1);
options = optimset('maxiter',100000,'display','off');
warning off
x = quadprog(H,f,A,b,Aeq,beq,lb,ub,x0,options);
alpha = x(1:n); 
warning on

% support vector
S = find(alpha > eps);
ns = length(S);
beta = alpha(S).*label(S);
sv = data(S,:);

% bias
if ns == 0
    beta0 = 0;
else
    M = find((alpha > 1e-4*max(alpha)) & (alpha < C - 1e-4*max(alpha)));
    if length(M) == 0
        beta0 = 0;
    else
    beta0 = mean(label(M) - sum(diag(beta)*ker(S,M))');
    end
end

% model
model.ns = ns;
model.sv = sv;
model.beta = beta;
model.beta0 = beta0;
model.sigma = sigma;