% demo data
N1 = 200; N2 = 20; N = N1 + N2;
l = [-ones(N1,1); ones(N2,1)]; % label
d = [-l/2 + randn(N,1)/2  -l-randn(N,1)/2]; % data

% plot original data for visual inspection
figure('color','w');
pos = find(l==1);
plot(d(pos,1),d(pos,2),'r.');
pos = find(l==-1);
hold on; plot(d(pos, 1),d(pos, 2),'b.');
axis equal

data = d;
label = l;

% svm method
% train_1: hard 2C-svm (soft margin for negative class 
% and hard margin for positive class
% train_2: svm classification with constraints on rare class 
% slack variables
svmtrain = @train_2;

% set grid search range
cmin = 2; cmax = 4; smin = 2; smax = 8;

% grid search for parameter C and sigma
% cross validation should be used with caution due to the imbalance
for log2c = log(cmin)/log(2):log(cmax)/log(2)
    for log2s = log(smin)/log(2):log(smax)/log(2)
        C = 2^(log2c);
        sigma = 2^(log2s);
        idx = crossvalind('Kfold',N,K);
        test_result = zeros(length(label),1);
        
        % K fold cross validation
        for i=1:K
            train_id = (idx==i);
            test_id = ~train_id;
            train_data = data(train_id,:);
            train_label = label(train_id);
            test_data = data(test_id,:);
            test_label = label(test_id);
            model = svmtrain(train_label,train_data,C,sigma);
            l = predict(test_data,model);
            test_result(test_id)=l;
        end
        
        % evaluation criteria
        cv = fmeasure(test_result,label);
        if (cv >= bestcv),
            bestcv = cv; bestc = C; bests = sigma;
            fprintf('%g %g %g (best C=%g, sigma=%g)\n', log2c, log2s, cv, bestc, bests, bestcv);
        end
    end
end

% After finding the best parameter value for C, we train the entire data
% again using this parameter value
model = svmtrain(label,data,bestc,bests);

% plot decision boundary
hold on
[xi,yi] = meshgrid([min(d(:,1)):0.1:max(d(:,1))],[min(d(:,2)):0.1:max(d(:,2))]);
dd = [xi(:),yi(:)];
l = predict(dd,model);
pos = find(l==1);
hold on;
redcolor = [1 0.8 0.8];
bluecolor = [0.8 0.8 1];
h1 = plot(dd(pos,1),dd(pos,2),'s','color',redcolor,'MarkerSize',5,'MarkerEdgeColor',redcolor,'MarkerFaceColor',redcolor);
pos = find(l==-1);
hold on;
h2 = plot(dd(pos,1),dd(pos,2),'s','color',bluecolor,'MarkerSize',5,'MarkerEdgeColor',bluecolor,'MarkerFaceColor',bluecolor);
uistack(h1, 'bottom');
uistack(h2, 'bottom');

