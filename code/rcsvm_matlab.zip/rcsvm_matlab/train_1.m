function model = train_1(label,data,C,sigma)

% svm classification: hard 2C-svm (soft margin for negative class and hard
% margin for positive class
% rare examples are denoted as positive instances
% C: penalty parameter
% sigma: kernel parameter

n = size(data,1);
d = size(data,2);
idxn = find(label == -1);
idxp = find(label == 1);
data = [data(idxn,:); data(idxp,:)];
label = [label(idxn); label(idxp)];
np = length(idxp);
nn = length(idxn);
ker = K(data,data,sigma);    % RBF kernel

%H = diag(label)*ker'*ker*diag(label);
H = (label*label').*ker;
H = H + 1e-10*eye(size(H));
f = -ones(n,1);
lb = zeros(n,1);
ub = C*ones(n,1);
ub(idxp) = inf;
A = []; b = []; Aeq = label'; beq = 0;
x0 = zeros(n,1);
options = optimset('maxiter',10000000,'display','off');
warning off
alpha = quadprog(H,f,A,b,Aeq,beq,lb,ub,x0,options);
warning on

% support vector
S = find(alpha > eps);
ns = length(S);
beta = alpha(S).*label(S);
sv = data(S,:);

% bias
if ns == 0
    beta0 = 0;
else
    M = find((alpha > 1e-4*max(alpha)) & (alpha < C - 1e-4*max(alpha)));
    if length(M) == 0
        beta0 = 0;
    else
    beta0 = mean(label(M) - sum(diag(beta)*ker(S,M))');
    end
end

% model
model.ns = ns;
model.sv = sv;
model.beta = beta;
model.beta0 = beta0;
model.sigma = sigma;