% Gaussian Kernel
function kernel = K(X,Y,sigma)
[n1 d1] = size(X);
[n2 d2] = size(Y);
A = repmat(sum(X.^2,2),1,n2);  % |X|^2
B = repmat(sum(Y.^2,2),1,n1);  % |Y|^2
D = A + B' - 2*(X * Y');
% Gaussian 
kernel = exp(-D/2/sigma^2);


