function f = fmeasure(l,l0)
% l: test label
% l0: groundtruth label
if length(l)~=length(l0)
    error('Label length is different.')
end

true = (l0==1);
false = ~true;

TP = sum(l0(true)==l(true));
FN = sum(true)-TP;
TN = sum(l0(false)==l(false));
FP = sum(false)-TN;

pre = TP/(TP+FP);
rec = TP/(TP+FN);
f = 2*(rec*pre)/(rec+pre);